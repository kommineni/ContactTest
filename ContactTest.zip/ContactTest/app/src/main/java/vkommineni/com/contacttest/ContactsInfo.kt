package vkommineni.com.contacttest

data class ContactsInfo(val contactId: String, val displayName: String, val phoneNumber: String)
